// Perlin Noise Project
// Isaac Munro
// Oct 06 2023
//


let currentX;
let currentY = 450;
let noisePosRect = 30;
let panPos = 20;  // initial position for panning
let avgY = 450; 
let average;

const noiseShift = 0.05;

function setup() {
  createCanvas(1200, 700);
  //genTerrain();

}

function keyPressed(){

}

function genTerrain(){  // generates terrain using noise to smooth it out
  rectMode(CORNERS);
  avgY = 0;
  currentX = 0;
  let flagY = 700; // variables for flag position
  let flagX = 0;
  while (currentX < width){
    //currentY = random(height);
    rect(currentX,currentY,currentX+2,700); // generates 1 terrain rectangle
    currentX += 2;
    currentY = noise(noisePosRect);
    currentY = map(currentY, 0, 1, 0, 700);
    noisePosRect += noiseShift;
    if (currentY < flagY){  // updates flag position if scanned y is higher than previous
      flagY = currentY;
      flagX = currentX;
      
    }
    avgY = avgY + currentY;
    
  }
  drawFlag(flagX,flagY);  // draws flag
  drawAverage(avgY);
}


function drawFlag(xpos, ypos){ // draws a ""flag"" (basically a windsock) at the tallest point in frame
  stroke(0,255,0);
  line(xpos,ypos,xpos+25,ypos-25);
  triangle(xpos+25,ypos-25, xpos+25, ypos-20, xpos, ypos);
  stroke(140,60,200);
}

function draw() {
  frameRate(10);
  background(700);
  noisePosRect = panPos+1;  // pans the frame right by incrementing the noise variable
  panPos +=1;
  genTerrain();
}


function drawAverage(totalY){ // draws the average height of terrain as canvaswide line
  average = totalY/600;
  stroke(255,0,0);
  strokeWeight(8);
  line(0,average, 1200, average);
  strokeWeight(2);
  stroke(140,60,200);
  
} 