// Multicolor Cube Project
// Isaac Munro
// Sep 27
//



let currentY = 0;
let currentX = 0;
let squareSize = 35;  // drawing size for colored squares


function setup() {
  createCanvas(900, 900);

  squareline(); // creates the initial multicolor grid

  document.addEventListener("contextmenu", event => event.preventDefault());  //removes default rightclick behavior
}

function squareline(){
  currentX =0;
  
  while (currentX < width){ // while the xposition is lower than width, generates vertical lines of squares
    currentY =0;
    while (currentY < height){  // nested loop to create the vertical squareline
      fill(random(255),random(255),random(255));
      square(currentX,currentY,squareSize);
      currentY = currentY + squareSize;
    }
    currentX = currentX + squareSize; // moves starting xpos for squareline one square to the right
  }
  
  
}

function mousePressed(){
  if (mouseButton === LEFT){  // regenerates squareline with smaller squares if leftclick
    if (squareSize < 6){
      print("Squares are as small as they can be");
    }
    else{
      squareSize = squareSize - 5;  // makes squares smaller and redraws squareline
      squareline();
    }
  }

  else{
    squareSize = squareSize + 5;  // makes squares bigger and redraws squareline
    squareline();
  }

}

function keyPressed(){  // clears and redraws squareline if any key is pressed
  clear();
  squareline();
}


function draw() {
  
}
